#include "ClickableLabel.h"

// 无需写任何额外代码！重写的事件和信号已在头文件实现
