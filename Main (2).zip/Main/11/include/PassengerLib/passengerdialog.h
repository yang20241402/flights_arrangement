#ifndef PASSENGERDIALOG_H
#define PASSENGERDIALOG_H

#include <QDialog>
#include <QSqlQuery>
#include <QSqlError>
#include <QStringLiteral>
#include <QTableWidget>
#include <QPushButton> // 按钮头文件
#include <QMap>        // 管理每行的按钮和选择状态

// 恢复乘机人信息结构体
struct PassengerInfo{
    QString name;
    QString idCard;
    QString phone;
    bool isValid = false; // 是否被选中
};

namespace Ui {
class PassengerDialog;
}

class PassengerDialog : public QDialog
{
    Q_OBJECT

public:
    explicit PassengerDialog(int userId, QWidget *parent = nullptr);
    ~PassengerDialog();
    // 新增：设置购票模式（控制按钮显示）
    void setBuyTicketMode(bool isBuyMode);
    // 新增：获取选中的乘机人信息
    PassengerInfo getSelectedPassenger(int row = -1); // row=-1取当前选中行

signals:
    // 新增：选中状态变化信号（供外部获取选择结果）
    void passengerSelected(const PassengerInfo &info);

private slots:
    void on_addBtn_clicked();
    void on_editBtn_clicked();
    void on_deleteBtn_clicked();
    // 新增：“选择/取消选择”按钮的点击槽函数
    void on_selectBtn_clicked();

private:
    Ui::PassengerDialog *ui;
    int m_userId;
    QSqlDatabase m_db;
    // 新增：购票模式标志
    bool m_isBuyTicketMode = false;
    // 新增：管理每行的选择按钮和选择状态（行号 → 按钮/是否选中）
    QMap<int, QPushButton*> m_rowSelectBtnMap;
    QMap<int, bool> m_rowSelectedMap;

    void loadPassengerData();
    void initDatabase();
    void setupLayout();
    // 新增：创建“选择”按钮的工具函数
    QPushButton* createSelectButton(int row);
};

#endif
